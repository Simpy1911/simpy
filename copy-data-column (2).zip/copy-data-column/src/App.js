import React, {Component} from 'react';

import './App.css';

class App extends  Component{
  constructor(props){
super(props);
this.state={
  students: [
    { id: 1, name: 'Sapna', dob: '21-Nov-2000' },
    { id: 2, name: 'Ali', dob:'22-Nov-2000' },
    { id: 3, name: 'Abhi', dob:'23-Nov-2000' },
    { id: 4, name: 'Aditya', dob:'24-Nov-2000' }
 ]
}
this.handleClick=this.handleClick.bind(this);
  }

 handleClick() {
  return this.state.students.map((student, index) => {
    const { id, name, dob } = student
    return (
       <tr key={id}>
          <td>{id}</td>
          <td>{name}</td>
          <td>{dob}</td>   
       </tr>
       
    )
 })

}
  
renderColumnData() {
  return this.state.students.map((student, index) => {
     const { id, name, dob } = student 
     return (
        <tr key={id}>
           <td>{id}</td>
           <td>{name}</td>
           <td>{dob}</td>   
        </tr>
     )
  })
}

render() {
  return (
     <div>
       <div>
        <h1 >Column A</h1>
        <table id='students'>
           <tbody>
              {this.renderColumnData()}
           </tbody>
        </table>
        </div>
        <br/>
        <div>
        <button  onClick={this.handleClick}>Populate</button>
        </div>
       
     </div>
  )
}
}
export default App;
